const Security=()=>{
    return(
        <>
        <div>
            welcome Security
        </div>
        </>
    )
}
export default Security